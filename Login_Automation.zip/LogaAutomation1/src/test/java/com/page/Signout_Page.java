package com.page;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Signout_Page {
	WebDriver driver;
	public void Launching(String browser,String URL) 
	//method for launching the chrome browser
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("internetexplorer"))
		{
			System.setProperty("webdriver.ie.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		driver.manage().window().maximize(); // to maximize window
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
		driver.get("https://google.com");
System.out.println(driver.getTitle());
	}
public void click(String xpath) 
// method for clicking Sign in and Sign out
{
	driver.findElement(By.xpath(xpath)).click();
}
public void entering(String xpath, String value) 
// method for entering user name and password while signing into the account
{
	driver.findElement(By.xpath(xpath)).sendKeys(value);
}
public void assertion(String xpath)
{
	String s1 = driver.findElement(By.xpath(xpath)).getText();
	Assert.assertEquals("ALREADY REGISTERED?", s1);
	System.out.println("signout successful");
}
}
