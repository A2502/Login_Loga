package com.stepdefinition;

import com.page.Invalid_Registration_Details_page;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class Invalid_Registration_Details_stepdefinition {
	Invalid_Registration_Details_page irp = new Invalid_Registration_Details_page (); 
	@Given("^open url in chrome browser$")
	public void open_URL_in_chrome_browser()  {
		
	  irp.Launching("chrome", "http://automationpractice.com/index.php?controller=authentication&back=my-account");
	  // Launching Loga Automation Practice website by entering the url 
	
	}

	@When("^Enter an Email$")
	public void enter_an_email()  {

	   irp.Entering("//*[@id=\"email_create\"]", "alekya2502@gmail.com"); 
	   // Inspected email text box by its xpath and entering the email in the email text box
	}

	@Then("^click on Create an account$")
	public void click_on_create_an_account() { 
	   
	  irp.clicking("//*[@id=\"SubmitCreate\"]/span");  
	  // Inspected create an account button by its xpath and clicking create an account
	}

	@Then("^select the title$")
	public void select_title() {

	    irp.clicking("//*[@id=\"id_gender2\"]");
	    // Inspected select title radio button by its xpath and selecting the title 
	}

	@Then("^enter the first name$")
	public void enter_first_name()  {
		
	   irp.Entering("//*[@id=\"customer_firstname\"]", "alekya");
		  // Inspected first name text box by its xpath and entering first name
	}

	@Then("^enter the last name$")
	public void enter_last_name() {
	    
	   irp.Entering("//*[@id=\"lastname\"]","m");
	   // Inspected last name text box by its xpath and entering last name
	   
	}

	@Then("^enter e-mail$")
	public void enter_email()  {
	   
	    irp.Entering("//*[@id=\"email\"]", "alekya@gmail.com");
	    // Inspected email text box by its xpath and entering email 
	}

	@Then("^ enter the password$")
	public void enter_password() {
	   
		irp.Entering("//*[@id=\"passwd\"]", "gmail");
		// Inspected password textbox by its xpath and entering password
	}

	@Then("^select Dob$")
	public void select_dob()  {
	  
		irp.clicking("//*[@id=\"days\"]");
		   irp.clicking("//*[@id=\"days\"]/option[18]");
		   irp.clicking("//*[@id=\"months\"]");
		   irp.clicking("//*[@id=\"months\"]/option[11]");
		  irp.clicking("//*[@id=\"years\"]");
		   irp.clicking("//*[@id=\"years\"]/option[26]");   
		   // Inspected day,month,year radio buttons by its xpath and entering dob 
	}

	@Then("^enter the first name in address$")
	public void enter_first_name_in_address()  {
	    
		irp.Entering("//*[@id=\"firstname\"]", "alekya");  
		// Inspected first name text box by its xpath and entering first name
	}

	@Then("^enter the last name in address $")
	public void enter_last_name_in_address()  {
	
		irp.Entering("//*[@id=\"lastname\"]", "m"); 
		// Inspected last name text box by its xpath and entering last name
	}

	@Then("^enter the company in address$")
	public void enter_company_in_address()  {
	   
		irp.Entering("//*[@id=\"company\"]", "lekya"); 
		// Inspected company name text box by its xpath and entering company name
	}

	@Then("^enter address in text box$")
	public void enter_address()  {
	   
		irp.Entering("//*[@id=\"address1\"]", "acom"); 
		// Inspected address text box by its xpath and entering address
	}

	@Then("^enter address line2 in text box$")
	public void enter_address_line(int arg1)  {
	    
		irp.Entering("//*[@id=\"address2\"]", "alekyaom");
		// Inspected address line2 text box by its xpath and entering company name
	}

	@Then("^enter the city$")
	public void enter_city() {
	    
		irp.Entering("//*[@id=\"city\"]", "aldshj"); 
		// Inspected city text box by its xpath and entering city
	}

	@Then("^select the state$")
	public void select_state()  {
	
		irp.clicking("//*[@id=\"id_state\"]");
		   irp.clicking("//*[@id=\"id_state\"]/option[11]");  
		   // Inspected state dropdown by its xpath and selecting the state
	}

	@Then("^enter Zip postal code$")
	public void enter_zip_postal_code()  {
	    
		irp.Entering("//*[@id=\"postcode\"]", "534260");
		// Inspected zip code text box by its xpath and entering zip code
	}

	@Then("^select the country$")
	public void select_country()  {
	    
		 irp.clicking("//*[@id=\"id_country\"]");  
		  irp.clicking("//*[@id=\"id_country\"]/option[2]");   
		  // Inspected Country dropdown and selecting the country
	}

	@Then("^enter the additional information$")
	public void enter_additional_information()  {
	    
		irp.Entering("//*[@id=\"other\"]", "alekyacom");
		// Inspected additional information text box by its xpath and entering additional information
	}

	@Then("^enter the home phone$")
	public void enter_home_phone()  {
	 
		irp.Entering("//*[@id=\"phone\"]", "8814528452");
		// Inspected home phone text box by its xpath and entering home phone
	}

	@Then("^enter the mobile phone$")
	public void enter_mobile_phone()  {
	
		irp.Entering("//*[@id=\"phone_mobile\"]", "9515748522");
		// Inspected mobile phone text box by its xpath and entering mobile phone
	}

	@Then("^enter assign an address in text box$")
	public void enter_assign_an_address()  {
	 
		irp.Entering("//*[@id=\"alias\"]", "fgfcgbvnh");
		// Inspected assign address text box by its xpath and entering address
	}

	@Then("^click on register button$")
	public void click_on_register()  {
	   
	   irp.clicking("//*[@id=\"submitAccount\"]/span"); 
	// Inspected register button by its xpath and clicking on register
	}
	@Then("^PoPuP message is displayed$")
	public void PoPuP_message_is_displayed()  {
	   
	   irp.ASsertion("//*[@id=\"center_column\"]/div/p"); 
	// pop message will be displayed on unsuccessful registration 
	}

	
}
