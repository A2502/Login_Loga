package com.stepdefinition;

import com.page.Signout_Page;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Signout_stepdefinition {
	Signout_Page sp = new Signout_Page();
	@Given("^Open url in the browser$")
	public void  Open_url_in_the_browser() {
		sp.Launching("chrome", "http://automationpractice.com/index.php"); 
		// Launching Loga Automation Practice website by entering the url
	}
	
	@When("^click on sign in$")
	public void  click_sign_in() {
	   
	  
	sp.click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
// Inspected signin button by its xpath and clicking signin button
	}
	@When("^Enter the username$")
	public void enter_username() {
	    
	sp.entering("//*[@id=\"email\"]", "mattasirimounica.selenium@gmail.com");
	// Inspected user name text box by its xpath and entering user name
	}

	@When("^Enter the password$")
	public void enter_password() {
	 
	  sp.entering("//*[@id=\"passwd\"]", "abc@123"); 
		// Inspected password text box by its xpath and entering password
	}

	@Then("^Click on Signout$")
	public void click_on_Signout()  {
	    
	 sp.click("/html/body/div/div[1]/header/div[2]/div/div/nav/div[2]/a" );   
		// Inspected Sign out button by its xpath and clicking sign out 
	}
	@Then("^PoPup message is displayed$")
	public void PoPup_message_is_displayed()  {
	    
	 sp.assertion("//*[@id=\"login_form\"]/h3");
	 // Pop up message wil be displayed on signing out the website
	}

}
