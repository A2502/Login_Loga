package com.stepdefinition;

import com.page.Valid_Registration_details_page;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Valid_Registration_details_stepdefinition {
	Valid_Registration_details_page rp = new Valid_Registration_details_page();
	
	@Given("^open URL in chrome browser$")
	public void open_URL_in_chrome_browser()  {
		
	  rp.Launching("chrome", "http://automationpractice.com/index.php?controller=authentication&back=my-account");
	  // Launching Loga Automation Practice website by entering the url 
	
	}

	@When("^Enter an email$")
	public void enter_an_email()  {
		
	   rp.Entering("//*[@id=\"email_create\"]", "alekya2502@gmail.com"); 
	// Inspected email text box by its xpath and entering the email in the email text box
	}

	@Then("^click on create an account$")
	public void click_on_create_an_account() { 
	   
	  rp.clicking("//*[@id=\"SubmitCreate\"]/span");  
	// Inspected create an account button by its xpath and clicking create an account
	}

	@Then("^select title$")
	public void select_title() {
	  
	    rp.clicking("//*[@id=\"id_gender2\"]");
	 // Inspected select title radio button by its xpath and selecting the title 
	}

	@Then("^enter first name$")
	public void enter_first_name()  {
	  
	   rp.Entering("//*[@id=\"customer_firstname\"]", "alekya");
	// Inspected first name text box by its xpath and entering first name
	}

	@Then("^enter last name$")
	public void enter_last_name() {
	    
	   rp.Entering("//*[@id=\"lastname\"]","m");
	// Inspected last name text box by its xpath and entering last name
	}

	@Then("^enter email$")
	public void enter_email()  {

	    rp.Entering("//*[@id=\"email\"]", "alekya@gmail.com");
	    // Inspected email text box by its xpath and entering email 
	}

	@Then("^enter password$")
	public void enter_password() {
	    
		rp.Entering("//*[@id=\"passwd\"]", "gmail");
		// Inspected password textbox by its xpath and entering password
	}

	@Then("^select dob$")
	public void select_dob()  {
	    // Write code here that turns the phrase above into concrete actions
		rp.clicking("//*[@id=\"days\"]");
		   rp.clicking("//*[@id=\"days\"]/option[18]");
		   rp.clicking("//*[@id=\"months\"]");
		   rp.clicking("//*[@id=\"months\"]/option[11]");
		   rp.clicking("//*[@id=\"years\"]");
		   rp.clicking("//*[@id=\"years\"]/option[26]");  
		// Inspected day,month,year radio buttons by its xpath and entering dob
	}

	@Then("^enter first name in address$")
	public void enter_first_name_in_address()  {
	   
		rp.Entering("//*[@id=\"firstname\"]", "alekya");  
		// Inspected first name text box by its xpath and entering first name
	}

	@Then("^enter last name in address$")
	public void enter_last_name_in_address()  {
	 
		rp.Entering("//*[@id=\"lastname\"]", "m");
		// Inspected last name text box by its xpath and entering last name
	}

	@Then("^enter company in address$")
	public void enter_company_in_address()  {
	  
		rp.Entering("//*[@id=\"company\"]", "lekya"); 
		// Inspected company name text box by its xpath and entering company name
	}

	@Then("^enter address$")
	public void enter_address()  {
	    
		rp.Entering("//*[@id=\"address1\"]", "acom"); 
		// Inspected address text box by its xpath and entering address
	}

	@Then("^enter address line(\\d+)$")
	public void enter_address_line(int arg1)  {
	    
		rp.Entering("//*[@id=\"address2\"]", "alekyaom");
		// Inspected address line2 text box by its xpath and entering company name
	}

	@Then("^enter city$")
	public void enter_city() {
	    
		rp.Entering("//*[@id=\"city\"]", "aldshj"); 
		// Inspected city text box by its xpath and entering city
	}

	@Then("^select state$")
	public void select_state()  {
	   
		rp.clicking("//*[@id=\"id_state\"]");
		   rp.clicking("//*[@id=\"id_state\"]/option[11]");  
		   // Inspected state dropdown by its xpath and selecting the state
	}

	@Then("^enter zip postal code$")
	public void enter_zip_postal_code()  {
	   
		rp.Entering("//*[@id=\"postcode\"]", "534260");
		// Inspected zip code text box by its xpath and entering zip code
	}

	@Then("^select country$")
	public void select_country()  {
	   
		 rp.clicking("//*[@id=\"id_country\"]");  
		  rp.clicking("//*[@id=\"id_country\"]/option[2]"); 
		  // Inspected Country dropdown and selecting the country
	}

	@Then("^enter additional information$")
	public void enter_additional_information()  {
		
		rp.Entering("//*[@id=\"other\"]", "alekyacom");
		// Inspected additional information text box by its xpath and entering additional information
	}

	@Then("^enter home phone$")
	public void enter_home_phone()  {
	  
		rp.Entering("//*[@id=\"phone\"]", "8814528452");
		// Inspected home phone text box by its xpath and entering home phone
	}

	@Then("^enter mobile phone$")
	public void enter_mobile_phone()  {
	    
		rp.Entering("//*[@id=\"phone_mobile\"]", "9515748522");
		// Inspected mobile phone text box by its xpath and entering mobile phone
	}

	@Then("^enter assign an address$")
	public void enter_assign_an_address()  {
	    
		rp.Entering("//*[@id=\"alias\"]", "fgfcgbvnh");
		// Inspected assign address text box by its xpath and entering address
	}

	@Then("^popup message is displayed$")
	public void popup_message_is_displayed()  {
	    
	   rp.AsseRtion("//*[@id=\"center_column\"]/p");
	   
		// Pop message will be displayed on successful registration 
	}


}
